package com.talal.javabased;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Appconfig {
	@Bean
	public Student getstd()
	{
		return new Student();
	}

}
