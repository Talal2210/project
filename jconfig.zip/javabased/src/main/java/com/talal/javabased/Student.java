package com.talal.javabased;

public class Student {
	public void feedback()
	{
		System.out.println("Student feedback");
	}

}
