import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.IconifyAction;

public class registerDao {
	
	private String dbUrl = "jdbc:mysql://localhost:3306/userdb";
	private String dbUname = "root";
	private String dbPassword = "root";
	private String dbDriver = "com.mysql.cj.jdbc.Driver";
	
	
	public void loadDriver(String dbDriver)
	
	{
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}
	
	
	
	public Connection getConnection()
	{
		Connection con = null;
		try {
			DriverManager.getConnection(dbUrl,dbUname,dbPassword);
			

			
			if (con != null)
			{
				System.out.print("chal gaya");
			}
			else
			{
				return null;
			}
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return con;
	}
	
	
//	if (con != null)
//	{
//		out.printwriter("chal gaya");
//	}
//	else
//	{
//		
//	}
//	
	
	public String insert(Member member)
	{
		loadDriver(dbDriver);
		Connection connection = getConnection();
		String result="Data entered successfully";
		String sql = "insert into member values (?,?,?,?)";
		
		PreparedStatement pS;
		try {
			pS= connection.prepareStatement(sql) ;
			
			pS.setString(1,member.getUname());
			pS.setString(2,member.getPassword());
			pS.setString(3,member.getEmail());
			pS.setString(4,member.getPhone());
			pS.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
			result= "data not entered";
			// TODO: handle exception
			
		}
		
		return result;
	}
	

}
