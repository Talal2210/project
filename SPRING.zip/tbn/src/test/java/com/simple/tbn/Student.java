package com.simple.tbn;

public class Student implements Person {

	public void feedback() {
		
		System.out.println("Student feedback");
		// TODO Auto-generated method stub
		
	}
	
	

}
