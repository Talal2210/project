package com.simple.tbn;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
	public void main (String[] args)
	{
		ApplicationContext con = new ClassPathXmlApplicationContext("config.xml");
		
		//AnnotationConfigApplicationContext con = new AnnotationConfigApplicationContext();
		//con.scan("com.simple.tbn");
		//con.refresh();
		//Person p= (Person)con.getBean(Person.class);
		//Person p=con.getBean(Person.class);
		
		//p.feedback();
		campus_name c=(campus_name)con.getBean("campusname");
		System.out.println(c);
		
	}
}
