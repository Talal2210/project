package com.simple.tbn;

public class campus_name {
	
	private String campusname;

	public String getCampusname() {
		return campusname;
	}

	public void setCampusname(String campusname) {
		this.campusname = campusname;
	}
	@Override
	public String toString()
	{
		return "Campus [campus_name= " + "]";
		
	}
	

}
