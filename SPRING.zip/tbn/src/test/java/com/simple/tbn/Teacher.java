package com.simple.tbn;

import org.springframework.stereotype.Component;

@Component
public class Teacher implements Person {
	
	
	public void feedback()
	{
		
		{
			System.out.println("HELLO IT'S ME Teacher's feedback");
		}
	}

}
