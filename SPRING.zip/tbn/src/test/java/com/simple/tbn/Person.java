package com.simple.tbn;

interface Person {
	

		
		public void feedback();
		
}
