package practice;

public class cat extends Pet{
	
 public cat(String name,int age) {
	 
	 super(name, age);
	// TODO Auto-generated constructor stub
}
 
 @Override
 public void speak()
 {
	  System.out.println("cat can speak meoww and its name is: "+name);
 };
 
}
