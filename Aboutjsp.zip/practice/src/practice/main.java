package practice;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		dog dog = new dog("PLEW",1);
		cat cat = new cat("simba",4);
		
		cat.speak();
		dog.speak();

	}

}
