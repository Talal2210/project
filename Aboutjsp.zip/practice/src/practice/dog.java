package practice;

public class dog extends Pet{
	
	
  public dog(String name,int age)
  {
	  super(name, age);
  }
  @Override
  public void speak()
  {
	  System.out.println("Dog can speak and it name is : "+name);
  };
}
